
<?php
if(isset($_POST['search'])){
$obj= mysqli_connect("127.0.0.1", "root", "", "online_doctor");

if(!$obj)
{
	die("SERVER PROBLEM".mysqli_connect_error());
}
 else{

 	$key = $_POST['key'];
 	echo $key;
 	$sql = "SELECT * FROM hospital_info WHERE disease LIKE 'Cancer'";
$result=mysqli_query($obj, $sql);
	if($result ){
		  while($row = mysqli_fetch_assoc($result)) {
		  	?>
		  	<h3><?php echo $row['hospital_name']?></h3><br>
		  	<p>Doctor Name : <?php echo $row['doctor_name']?></p><br>
		  	<p>Contact : <?php echo $row['mobile_number']?></p><br>
		  	<p>Alternate contact :<?php echo $row['alternate_mobile_number']?></p><br>
		  	<p>Email id : <?php echo $row['email_id']?></p>
	<?php	  }}else{
		echo "Not entered";
	}

 }
}
?>
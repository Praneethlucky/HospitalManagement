-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 08, 2020 at 07:19 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_doctor`
--

-- --------------------------------------------------------

--
-- Table structure for table `hospital_info`
--

DROP TABLE IF EXISTS `hospital_info`;
CREATE TABLE IF NOT EXISTS `hospital_info` (
  `id` varchar(200) NOT NULL,
  `hospital_name` varchar(300) NOT NULL,
  `location` varchar(1000) NOT NULL,
  `disease` varchar(300) NOT NULL,
  `doctor_name` varchar(300) NOT NULL,
  `mobile_number` bigint(100) NOT NULL,
  `alternate_mobile_number` bigint(100) NOT NULL,
  `email_id` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital_info`
--

INSERT INTO `hospital_info` (`id`, `hospital_name`, `location`, `disease`, `doctor_name`, `mobile_number`, `alternate_mobile_number`, `email_id`) VALUES
('vdT1jYpiUl', 'Care', 'Gachibowli', 'Diabetic', 'Mahebub', 9876544321, 987654332, 'vikram.1837@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

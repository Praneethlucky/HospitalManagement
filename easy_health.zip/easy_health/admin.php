<form method="GET" action="insert_data.php">
 <input type="submit" name ="New Enroll" value="New Enroll">
</form>
<br>
<?php
	
$obj= mysqli_connect("127.0.0.1", "root", "", "online_doctor");

if(!$obj)
{
	die("SERVER PROBLEM".mysqli_connect_error());
}
  else{
  	$sql="SELECT * FROM hospital_info ";
	$result=mysqli_query($obj, $sql);
	if($result && mysqli_num_rows($result)>0){
		  while($row = mysqli_fetch_assoc($result)) {
 ?>
 <form method="post" action="update_or_delete.php">
        <input type="radio" name ="hospital_id" value =<?php echo $row['id']?> ><?php echo $row['hospital_name']," ",$row['location']," ",$row['mobile_number']; ?><br>
 <?php
    
	}
	?>
	       <input type="submit" name ="Update" value = "Update">
          <input type="submit" name ="Delete" value="Delete">
    </form>
    <?php
  }else{
		echo "No Hospital data";
	}
}
?>



<?php
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
 
function generate_string($input, $strength = 16) {
    $input_length = strlen($input);
    $random_string = '';
    for($i = 0; $i < $strength; $i++) {
        $random_character = $input[mt_rand(0, $input_length - 1)];
        $random_string .= $random_character;
    }
 
    return $random_string;
}
if(isset($_POST['submit'])){
  
$obj= mysqli_connect("127.0.0.1", "root", "", "online_doctor");

if(!$obj)
{
  die("SERVER PROBLEM".mysqli_connect_error());
}else{
  $hospital_name = $_POST['hospital_name'];
  $location = $_POST['location'];
  $disease = $_POST['disease'];
  $doctor_name = $_POST['doctor_name'];
  $number = $_POST['number'];
  $alternate_number=$_POST['alternate_number'];
  $email = $_POST['email'];
  $id = generate_string($permitted_chars,10);

  $sql="INSERT INTO hospital_info VALUES('$id','$hospital_name','$location','$disease','$doctor_name','$number','$alternate_number','$email')";
  $result=mysqli_query($obj, $sql);
  if($result){
      header("Location: ../easy_health/admin.php?insert=success"); 
    exit();



  }

}
}

?>




<!DOCTYPE html>
<html>
<body>

<h2>HTML Forms</h2>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <label for="fname">Hospital name:</label><br>
  <input type="text"  name="hospital_name" ><br>
  <label for="lname">Location :</label><br>
  <input type="text" name="location"><br>

  <label for="lname">Disease :</label><br>
  <input type="text" name="disease"><br>

  <label for="lname">Doctor name :</label><br>
  <input type="text" name="doctor_name"><br>
    <label for="quantity">number:</label><br>
  <input type="number"  name="number" ><br>

    <label for="quantity">Alternate Number:</label><br>
  <input type="number"  name="alternate_number" ><br>
    <label for="lname">Email :</label><br>
  <input type="email" name="email"><br>
  <input type="submit" name ="submit" >
</form> 


</body>
</html>


<?php
if(isset($_POST['update_it'])){

$obj= mysqli_connect("127.0.0.1", "root", "", "online_doctor");

if(!$obj)
{
  die("SERVER PROBLEM".mysqli_connect_error());
}else{
	$id = $_POST['id'];
		 $hospital_name = $_POST['hospital_name'];
  $location = $_POST['location'];
  $disease = $_POST['disease'];
  $doctor_name = $_POST['doctor_name'];
  $number = $_POST['number'];
  $alternate_number=$_POST['alternate_number'];
  $email = $_POST['email'];

  $sql = "UPDATE hospital_info SET hospital_name='$hospital_name' , location='$location', disease='$disease', doctor_name='$doctor_name',mobile_number = '$number',alternate_mobile_number= '$alternate_number',email_id = '$email' WHERE id = '$id'";
  	$result=mysqli_query($obj, $sql);
  	if($result){
  		 header("Location: ../easy_health/admin.php?update=success"); 
    	exit();
  	}
}

}
if(isset($_POST['Update'])){
	
	$obj= mysqli_connect("127.0.0.1", "root", "", "online_doctor");

if(!$obj)
{
  die("SERVER PROBLEM".mysqli_connect_error());
}else{
	$id = $_POST['hospital_id'];
	$sql="SELECT * FROM hospital_info WHERE id = '$id'";
	$result=mysqli_query($obj, $sql);
	if($result and mysqli_num_rows($result)==1){
		$row = mysqli_fetch_assoc($result);

	
	?>


<!DOCTYPE html>
<html>
<body>

<h2>HTML Forms</h2>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
	<input type="hidden" id="id" value=<?php echo $id ?>>
  <label for="fname">Hospital name:</label><br>
  <input type="text"  name="hospital_name" value=<?php echo $row['hospital_name']?>><br>
  <label for="lname">Location :</label><br>
  <input type="text" name="location" value=<?php echo $row['location']?> ><br>

  <label for="lname">Disease :</label><br>
  <input type="text" name="disease" value=<?php echo $row['disease']?>><br>

  <label for="lname">Doctor name :</label><br>
  <input type="text" name="doctor_name" value=<?php echo $row['doctor_name']?>><br>
    <label for="quantity">number:</label><br>
  <input type="number"  name="number" value=<?php echo $row['mobile_number']?> ><br>

    <label for="quantity">Alternate Number:</label><br>
  <input type="number"  name="alternate_number" value=<?php echo $row['alternate_mobile_number']?> ><br>
    <label for="lname">Email :</label><br>
  <input type="email" name="email" value=<?php echo $row['email_id']?>><br>
  <input type="submit" name ="update_it" value="Update it">
</form> 
</body>
</html>

	<?php
	}
 } 
}
if(isset($_POST['Delete'])){

$obj= mysqli_connect("127.0.0.1", "root", "", "online_doctor");

if(!$obj)
{
  die("SERVER PROBLEM".mysqli_connect_error());
}else{
	$id = $_POST['hospital_id'];

  $sql = "DELETE FROM hospital_info where id = '$id'";
  	$result=mysqli_query($obj, $sql);
  	if($result){
  		 header("Location: ../easy_health/admin.php?delete=success"); 
    	exit();
  	}
}

}
?>